

    function IsEmpty() {
        if (document.getElementById("input").value="") {

        document.getElementById("ee").innerHTML="wew";
          return false;

        }

        return true;

      }